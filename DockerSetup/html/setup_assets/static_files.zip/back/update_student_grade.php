<?php
require 'db.php'
//Allow Professor to Update Grade & Add Comments


function update_grade($exam_id, )
{
	
}
function add_comment()
{
	
}

?>