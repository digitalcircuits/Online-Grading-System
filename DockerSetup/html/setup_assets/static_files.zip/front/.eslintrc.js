module.exports = {
    rules: {
        'no-console': 'off',
    },
    parserOptions: {
        'ecmaVersion': '2017',
    },
    env: {
        'es6': true
    }
};
